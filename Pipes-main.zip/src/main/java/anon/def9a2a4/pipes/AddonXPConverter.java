package anon.def9a2a4.pipes;

import com.destroystokyo.paper.event.entity.EntityAddToWorldEvent;
import org.bukkit.Material;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.inventory.ItemStack;
import anon.def9a2a4.pipes.PipesPlugin;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Random;

public class AddonXPConverter implements Listener {
    
    @EventHandler
    public void onEntitySpawn(EntityAddToWorldEvent e) {
        if(PipesPlugin.checkxp == 0) return;
        if(!(e.getEntity() instanceof ExperienceOrb xp)) return;
        if(xp.isFromBottle()) return;
        if(xp.getSpawnReason()!=ExperienceOrb.SpawnReason.UNKNOWN) return;
        xp.getServer().getScheduler().runTask(PipesPlugin.instance, () -> {
            System.out.println("---TYPE: COMMAND/CHEAT^^---");
            
            int beg = xp.getExperience();
            System.out.println("BEG: " + beg);

            int use = beg - (beg % 10);
            System.out.println("USE: " + use);

            int bonus = new Random().nextInt(4);
            int bottles = use / 10 + bonus + 1;
            System.out.println("BOTTLES: " + bottles);

            xp.getWorld().dropItemNaturally(xp.getLocation(), new ItemStack(Material.EXPERIENCE_BOTTLE, bottles));
            System.out.println("XP DONE");

            xp.remove();
        });
    }
    @EventHandler
    public void onMobDeath(EntityDeathEvent e) {
        if (PipesPlugin.checkxp == 0) return;
        int beg = e.getDroppedExp();
        if (beg<=0) return;
        System.out.println("---TYPE: ENTITY---");
        e.setDroppedExp(0);

        System.out.println("BEG: " + beg);

        int use = beg-(beg%10);
        System.out.println("USE: "+use);
        int bonus = new Random().nextInt(4);
        int bottles = (use/10)+bonus+1;
        System.out.println("BOTTLES: "+bottles);

        ItemStack bottle = new ItemStack(Material.EXPERIENCE_BOTTLE, bottles);
        e.getEntity().getWorld().dropItemNaturally(
                e.getEntity().getLocation(),
                bottle
        );
    }
}
